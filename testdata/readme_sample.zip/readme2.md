---
title: "Second Test Document"
slug: second-doc
category: API Reference
---

# Second Test Document

This is another test document.

## API Endpoints

Example endpoint documentation here.

## Authentication

Authentication details here. 